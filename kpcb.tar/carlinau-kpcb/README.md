# kpcb-2016challenge
Hashmap
#Instructions
Its required to compile this before running

Text file must be in the same folder as where you're running the program

One line command: javac hashmap.java; java hashmap [text file name]

To compile:
javac hashmap.java

To run:
java hashmap [text file]
